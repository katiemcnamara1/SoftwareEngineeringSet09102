﻿using System;
using Textreader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class TwitterTest
    {
        twitter twitterTest = new twitter();
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void tweetHeadingF()
        {
            twitterTest.TweetHeading= "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void tweetHeadingP()
        {
            twitterTest.TweetHeading = "a heading";
            string headingPass = "a heading";

            Assert.AreEqual(headingPass, twitterTest.TweetHeading);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void tweetBodyF()
        {
            twitterTest.TweetBody = "Character Count & Word Count Tool is a free character counter tool that provides instant character count & word count statistics for a given text ";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void tweetBodyP()
        {
            twitterTest.TweetBody = "a body";
            string bodyPass = "a body";

            Assert.AreEqual(bodyPass, twitterTest.TweetBody);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void twitterHandleF()
        {
            twitterTest.TwitterHandle = "@hellotheremytwitterhandleislong";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void twitterHandleP()
        {
            twitterTest.TwitterHandle = "@ahandle";
            string handlePass = "@ahandle";

            Assert.AreEqual(handlePass, twitterTest.TwitterHandle);
        }





    }
}
