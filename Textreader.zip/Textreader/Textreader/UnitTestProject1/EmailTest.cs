﻿using System;
using Textreader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class EmailTest
    {
        email emailTest = new email();

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailHeaderF()
        {
            emailTest.EmailHeader = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailHeaderP()
        {
            emailTest.EmailHeader = "a heading";
            string headerPass = "a heading";

            Assert.AreEqual(headerPass, emailTest.EmailHeader);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailTextF()
        {
            emailTest.EmailText = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailTextp()
        {
            emailTest.EmailText = "a heading";
            string textPass = "a heading";

            Assert.AreEqual(textPass, emailTest.EmailText);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailAddressF()
        {
            emailTest.EmailText = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailAddressP()
        {
            emailTest.EmailAddress = "a heading";
            string addressPass = "a heading";

            Assert.AreEqual(addressPass, emailTest.EmailText);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailBodyF()
        {
            emailTest.EmailText = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void emailBodyP()
        {
            emailTest.EmailBody = "a body";
            string bodyPass = "a body";

            Assert.AreEqual(bodyPass, emailTest.EmailBody);
        }


    }
}
