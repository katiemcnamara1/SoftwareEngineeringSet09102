﻿using System;
using Textreader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class SmsTest
    {
        sms smsTest = new sms();
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsBodyF()
        {
            smsTest.SmsBody = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsBodyP()
        {
            smsTest.SmsBody = "a body";
            string bodyPass = "a body";

            Assert.AreEqual(bodyPass, smsTest.SmsBody);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsNoF()
        {
            smsTest.SmsNo = "";
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsNoP()
        {
            smsTest.SmsNo = " a number";
            string noPass = " a number";

            Assert.AreEqual(noPass, smsTest.SmsNo);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsTextF()
        {
            smsTest.SmsText = "";
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void smsTextP()
        {
            smsTest.SmsText = "a text";
            string textPass = "a text";

            Assert.AreEqual(textPass, smsTest.SmsText);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void messageHF()
        {
            smsTest.MessageH = "";
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void messageHP()
        {
            smsTest.MessageH = "a message";
            string messagePass = "a message";

            Assert.AreEqual(messagePass, smsTest.MessageH);
        }


    }
}
