﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Textreader
{
    public class email
    {
        private string emailHeader;
        private string emailText;
        private string emailAddress;
        private string emailBody;


        public string EmailHeader
        {
            get { return emailHeader; }
            set
            {
                if (value == "")
                {
                    throw new ArgumentException("");
                }

                emailHeader = value;
            }
        }

        public string EmailText
        {
            get { return emailText; }
            set
            {
                if (value == "")
                {
                    throw new ArgumentException("");
                }

                emailText = value;
            }
        }

        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                if (value == "")
                {
                    throw new ArgumentException("");
                }

                emailAddress = value;
            }
        }

        public string EmailBody
        {
            get { return emailBody; }
            set
            {
                if (value == "")
                {
                    throw new ArgumentException("");
                }

                emailBody = value;
            }
        }
    }
}
