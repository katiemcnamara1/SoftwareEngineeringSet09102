﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace Textreader
{
    public class Data
    {

        public string[][] fileRead()
        {
            var readL = new List<string[]>();
            int row = 0;
            string filePath = @"textwords.csv";
            StreamReader sr = new StreamReader(filePath);
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split(',');
                readL.Add(line);
                row++;

            }

            var Output = readL.ToArray();
            return Output;
        }

        
        public Boolean PhoneNumberUK(string phoneNumberUK)
        {
            if (phoneNumberUK.Length == 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<string> Input(string input)
        {
            List<string> Output = new List<string>(input.Split(null));
            return Output;
        }

       
        public Boolean PhoneNumberES(string phoneNumberES)
        {
            if (phoneNumberES.Length == 9)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
       
        public Boolean phoneNumberChina(string phoneNumberChina)
        {
            if (phoneNumberChina.Length == 11)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string abbreviations(List<String> Input, string[][] abbreviations)
        {
            bool abb = false;
            string outputAbb = "";
            foreach (var i in Input)
            {
                abb = true;
                var temp = i[0];
                string y = "";
                if (char.IsUpper(temp))
                {
                    for (int j = 0; j < abbreviations.Length; j++)
                    {
                        y = abbreviations[j][0];
                        if (i.Equals(y))
                        {
                            outputAbb += " <" + abbreviations[j][1] + "> ";

                        }
                        else if (abb == true)
                        {
                            outputAbb += i;
                            outputAbb += " ";
                            abb = false;
                        }

                    }

                }
                else
                {
                    outputAbb += i;
                    outputAbb += " ";
                }
            }
            return outputAbb;
        }


        public Boolean validD(string id)
        {
            try
            {
                DateTime dt = DateTime.Parse(id);
                return true;
            }
            catch
            {
                return false;
            }
        }

        
        public Boolean emailLengths(string subject, string body)
        {
            if (subject.Length > 20)
            {
                MessageBox.Show("subject not correct length");
                return false;
            }
            else
            {
                
                if (body.Length > 1028)
                {
                    MessageBox.Show("body too long ");
                    return false;
                }
                else
                {
                    return true;
                }

            }
        }
        
        public bool sir(List<string> input)
        {
            if (input.Count == 2)
            {
                if (input[0].Equals("SIR"))
                {
                    try
                    {
                        DateTime dt = DateTime.Parse(input[1]);
                        return true;
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }
       
        public Boolean emailV(string input)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(input);
                return addr.Address == input;
            }
            catch
            {
                return false;
            }
        }


        
        public string sortCode(List<string> x)
        {
            bool sort = false;
            string sc = x[0] + " " + x[1];
            if (sc.Equals("Sort Code:"))
            {
                if (Regex.Match(x[2], @"\b([0-9]{2})-([0-9]{2})-([0-9]{2})\b").Success)
                {
                    sort = true;
                    if (sort == true)
                    {
                        return x[2];
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    MessageBox.Show("not right ");
                    return null;
                }
            }
            else
            {
                MessageBox.Show("not right");
                return null;

            }
        }

        
        public string incidentNature(List<String> x)
        {
            int valueNature = 0;
            List<string> natures = new List<string>();
            natures.Add("Theft");
            natures.Add("Intelligence");
            natures.Add("Terrorism");
            natures.Add("Raid");
            natures.Add("ATM");
            natures.Add("Customer");
            natures.Add("Staff");
            natures.Add("Bomb");
            natures.Add("Staff");
            natures.Add("Suspicious");
            natures.Add("Cash");
            string noi = x[3] + " " + x[4] + " " + x[5];
            if (noi.Equals("Nature of Incident:") || noi.Equals("Nature Of Incident:"))
            {
                for (int i = 0; i < natures.Count; i++)
                {
                    if (x[6].Equals(natures[i]))
                    {
                        valueNature = i;
                    }
                }
                if (valueNature < 4)
                {
                    return natures[valueNature];
                }
                else if ((valueNature == 4) && (x[7].Equals("Theft")))
                {
                    return (natures[valueNature] + "Theft");
                }
                else if ((valueNature == 5) && (x[7].Equals("Attack")))
                {
                    return (natures[valueNature] + "Attack");
                }
                else if ((valueNature == 6) && (x[7].Equals("Abuse")))
                {
                    return (natures[valueNature] + "Abuse");
                }
                else if ((valueNature == 7) && (x[7].Equals("Threat")))
                {
                    return (natures[valueNature] + "Threat");
                }
                else if ((valueNature == 8) && (x[7].Equals("Attack")))
                {
                    return (natures[valueNature] + "Attack");
                }
                else if ((valueNature == 9) && (x[7].Equals("Incident")))
                {
                    return (natures[valueNature] + "Incident");
                }
                else if ((valueNature == 10) && (x[7].Equals("Loss")))
                {
                    return (natures[valueNature] + "Loss");
                }
                else
                {
                    MessageBox.Show("Nature is incorrect");
                    return null;
                }
            }
            else
            {
                return null;
            }

        }


        
        public List<String> containUrl(List<string> input)
        {
            List<string> outputUrl = new List<string>();
            for (int i = 0; i < input.Count; i++)
            {
                if (input[i].Contains("www.") || input[i].Contains("http://") || input[i].Contains("https://"))
                {
                    outputUrl.Add(input[i]);
                }
            }
            return outputUrl;
        }

        
     


    }
}
